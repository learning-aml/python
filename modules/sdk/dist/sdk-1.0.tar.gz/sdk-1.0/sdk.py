def add(a : int, b : int) ->  int:
    return a + b

print(add(1, 2))
print(add('a', 'b'))

print("")