from setuptools import setup

setup(
    name="sdk",
    version='1.0',
    description='demo',
    author='zhangzhihong',
    author_email="zhangzhihong@huawei.com",
    url='',
    py_modules=['sdk']
)